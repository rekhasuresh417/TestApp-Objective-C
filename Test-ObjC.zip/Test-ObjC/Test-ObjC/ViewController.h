//
//  ViewController.h
//  Test-ObjC
//
//  Created by idsoftsource on 03/06/20.
//  Copyright © 2020 idsoftsource. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AddressBook/ABAddressBook.h>
#import <AddressBookUI/AddressBookUI.h>

@interface ViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    NSMutableArray *imgArray, *titleArray, *contactList;
}

@property (weak, nonatomic) IBOutlet UITableView *scrollTableView;
@property (weak, nonatomic) IBOutlet UITableView *verticalTableView;

@end

