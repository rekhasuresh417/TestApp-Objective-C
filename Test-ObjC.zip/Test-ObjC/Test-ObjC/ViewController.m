//
//  ViewController.m
//  Test-ObjC
//
//  Created by idsoftsource on 03/06/20.
//  Copyright © 2020 idsoftsource. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
   
    imgArray = [[NSMutableArray alloc]initWithObjects:
    @"img1.jpg",@"img2.jpg",@"img3.jpg",
    @"img4.jpg",@"img5.jpg",@"img6.jpg",
    @"img7.jpg",@"img8.jpg",@"img9.jpg",
    @"img10.jpg",@"img11.jpg",@"img12.jpg", nil];
    
    ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, NULL);

    __block BOOL accessGranted = NO;

    if (&ABAddressBookRequestAccessWithCompletion != NULL) { // We are on iOS 6
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);

        ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error) {
            accessGranted = granted;
            dispatch_semaphore_signal(semaphore);
        });

        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
        //dispatch_release(semaphore);
    }

    else { // We are on iOS 5 or Older
        accessGranted = YES;
        [self getContactsWithAddressBook:addressBook];
    }

    if (accessGranted) {
        [self getContactsWithAddressBook:addressBook];
    }
}

#pragma mark - Table View Data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:
(NSInteger)section{
    return imgArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:
(NSIndexPath *)indexPath{
    static NSString *cellId = @"cell2";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:
                             cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:
                UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
   
    UIImageView *img = (UIImageView *)[cell viewWithTag:11];
   img.layer.borderWidth = 1.0f;
    img.layer.borderColor = [UIColor grayColor].CGColor;
    img.layer.cornerRadius = 25.0f;
    img.image = [UIImage imageNamed:[imgArray objectAtIndex:indexPath.row]];
    
     UILabel *title = (UILabel *)[cell viewWithTag:12];
    if (contactList.count > indexPath.row) {
         title.text = [contactList objectAtIndex:indexPath.row];
    }else {
        title.text = [contactList objectAtIndex:indexPath.row-(indexPath.row-2)];
    }
   
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80.0;
}

#pragma mark - CollectionView Data Source

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return imgArray.count;
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell1" forIndexPath:indexPath];

    UIImageView *img = (UIImageView *)[cell viewWithTag:1];
    img.layer.borderWidth = 1.0f;
    img.layer.borderColor = [UIColor grayColor].CGColor;
    img.layer.cornerRadius = 42.0f;
    img.image = [UIImage imageNamed:[imgArray objectAtIndex:indexPath.row]];
    
   
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(100, 100);
}

#pragma mark - Request permission for access contacts list
// Get the contacts.
- (void)getContactsWithAddressBook:(ABAddressBookRef )addressBook {

    contactList = [[NSMutableArray alloc] init];
    CFArrayRef allPeople = ABAddressBookCopyArrayOfAllPeople(addressBook);
    CFIndex nPeople = ABAddressBookGetPersonCount(addressBook);

    for (int i=0;i < nPeople;i++) {

        ABRecordRef ref = CFArrayGetValueAtIndex(allPeople,i);

        //For username and surname
        ABMultiValueRef phones =(__bridge ABMultiValueRef)((__bridge NSString*)ABRecordCopyValue(ref, kABPersonPhoneProperty));

        CFStringRef firstName, lastName;
        firstName = ABRecordCopyValue(ref, kABPersonFirstNameProperty);
        lastName  = ABRecordCopyValue(ref, kABPersonLastNameProperty);

         [contactList addObject:[NSString stringWithFormat:@"%@ %@", firstName, lastName]];
       
    }
    NSLog(@"Contacts = %@",contactList);
    [_verticalTableView reloadData];
}
@end
