//
//  SceneDelegate.h
//  Test-ObjC
//
//  Created by idsoftsource on 03/06/20.
//  Copyright © 2020 idsoftsource. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

